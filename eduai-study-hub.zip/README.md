# EduAI Study Hub

A starter ChatGPT-powered study assistant for schools with anti-cheating features.